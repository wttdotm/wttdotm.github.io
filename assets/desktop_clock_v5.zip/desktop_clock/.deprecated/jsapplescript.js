(() => {
    const app = Application("Finder");
    app.includeStandardAdditions = true;
    app.displayDialog(`You have mail accounts`);
})()