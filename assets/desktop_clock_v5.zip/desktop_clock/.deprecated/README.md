# Clock Script

This repo is so much bigger than it needs to be but I think it's funny to see the trail of mess I left in writing what ended up being a total of literally a tiny piece of code and a cronjob. I had to learn trig!

## How To Run

I will fill this in later but basically all you do is run make_arrow_once.py with a cronjob.

~~## How To Run

First, you should make a somewhat circular clock on your desktop with whatever you want! Pictures, screenshots, symbols, just be able to look at it to tell time.

Clone this repo, replace the very last line of `make_arrow_once.py` with your own route/to/your/desktopIcon and name the output png whatever you want. 

Run it once, this will make the file on your desktop. Drag that file into the center of the clock. It~~