import cv2
import numpy as np
from PIL import Image
import datetime
now = datetime.datetime.now()
import math

# print(now.hour*60 + now.minute)
for h in range (12):
    for m in range(60):
        # Create an empty solid blue image
        width, height = 1000, 1000
        im = Image.new('RGBA', (width,height), (255,255,255,0))


        hour_degrees = ((h * 60 + (m)) / 2) + 270
        minute_degrees = (m * 6) + 270
        im = Image.new('RGBA', (1000,1000), (255,255,255,0))
        class Center:
            x = 500
            y = 500

        center = Center()

        # Make into Numpy array so we can use OpenCV drawing functions
        na = np.array(im)
        # print(type(na))
        # umat_version = cv2.UMat(np.array(na, dtype=np.uint8))
        # na = cv2.cvtColor(na, cv2.COLOR_RGBA2BGRA)

        # Draw arrowed line, from 10,20 to w-40,h-60 in black with thickness 30 pixels
        #make hour hand
        na = cv2.arrowedLine(na, (center.x,center.y), (int(center.x + (math.cos(math.radians(-hour_degrees)) * 200)), int(center.y - (math.sin(math.radians(-hour_degrees)) * 200))), (0,0,0, 255), 50)
        # print(type(na))
        #make minute hand
        na = cv2.arrowedLine(na, (center.x,center.y), (int(center.x + (math.cos(math.radians(-minute_degrees)) * 400)), int(center.y - (math.sin(math.radians(-minute_degrees)) * 400))), (0,0,0, 255), 50)

        # na = cv2.UMat.get(na)
        # na = cv2.UMat.get(umat_version)

        # na = cv2.UMat.get(umat_version)
        # print(f"Type of na after UMat conversion: {type(na)}, shape: {na.shape}, dtype: {na.dtype}")

        Image.fromarray(na).save(f'./all_clocks2/{'{:02}'.format(h)}_{'{:02}'.format(m)}.png')
        print(f"{h}_{m}")